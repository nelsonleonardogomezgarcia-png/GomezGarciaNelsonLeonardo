// /subscriber/persistence-subscriber.js

const mqtt = require('mqtt');
const { InfluxDB, Point } = require('@influxdata/influxdb-client');
const config = require('../config');
const ms = 1000;

// Influx config
const influxUrl = process.env.INFLUXDB_URL || 'http://localhost:8086';
const influxToken = process.env.INFLUXDB_TOKEN || 'mySuperSecretToken123!';
const influxOrg = process.env.INFLUXDB_ORG || 'utp';
const influxBucket = process.env.INFLUXDB_BUCKET || 'sensors';

// MQTT client
const brokerUrl = `mqtt://${config.broker.address}:${config.broker.port}`;
const topic = config.topics.telemetry('+');
const clientId = `persistence_sub_${Math.random().toString(16).slice(2, 8)}`;
const mqttClient = mqtt.connect(brokerUrl, { clientId });

// Clocks
const VECTOR_PROCESS_COUNT = 5;
const PROCESS_ID = parseInt(process.env.PROCESS_ID || '2');
let vectorClock = new Array(VECTOR_PROCESS_COUNT).fill(0);
let lamportClock = 0;

// Tracking per-device last logical clocks / last timestamp
const lastLamportPerDevice = {};
const lastVectorPerDevice = {};
const lastSeenTimestampPerDevice = {};

// Influx
const influxDB = new InfluxDB({ url: influxUrl, token: influxToken });
const writeApi = influxDB.getWriteApi(influxOrg, influxBucket, 'ns');

console.log('[INFO] Iniciando Suscriptor de Persistencia...');

mqttClient.on('connect', () => {
  console.log(`[INFO] Conectado al broker MQTT en ${brokerUrl}`);
  mqttClient.subscribe(topic, { qos: 1 }, (err) => {
    if (!err) console.log(`[INFO] Suscrito a telemetría en: ${topic}`);
    else console.error('[ERROR] Error al suscribirse a MQTT:', err);
  });
});

mqttClient.on('message', (receivedTopic, message) => {
  lamportClock++;
  vectorClock[PROCESS_ID]++;

  console.log(`\n[MSG] Mensaje recibido en [${receivedTopic}]`);
  try {
    const data = JSON.parse(message.toString());
    const deviceId = data.deviceId;

    const receivedLamportTS = data.lamport_ts || 0;
    const receivedVectorClock = data.vector_clock || new Array(VECTOR_PROCESS_COUNT).fill(0);

    // Fusion Lamport y Vector en persistencia (para monitor)
    lamportClock = Math.max(lamportClock, receivedLamportTS);
    if (!lastLamportPerDevice[deviceId]) lastLamportPerDevice[deviceId] = 0;
    if (!lastVectorPerDevice[deviceId]) lastVectorPerDevice[deviceId] = new Array(VECTOR_PROCESS_COUNT).fill(0);

    // Check required fields
    if (!deviceId || data.temperatura === undefined || data.humedad === undefined) {
      console.warn('[WARN] Mensaje incompleto recibido, ignorando:', data);
      return;
    }

    // Time validation (Barrera temporal)
    const msgTime = new Date(data.timestamp || Date.now()).getTime();
    const localTime = Date.now();
    const deltaMs = Math.abs(msgTime - localTime);

    // Helper to check vector consistency: received >= last known for all entries except sender can be equal/greater
    function vectorIsConsistent(received, lastKnown) {
      for (let i = 0; i < Math.max(received.length, lastKnown.length); i++) {
        const r = received[i] || 0;
        const l = lastKnown[i] || 0;
        if (r < l) return false;
      }
      return true;
    }

    // If message is too far in future/past (>2s) -> discard unless exception
    if (deltaMs > 2000) {
      // Exception: if Lamport higher than last seen for this device AND vector clock consistent -> accept but force HoraLocal
      const lastLamport = lastLamportPerDevice[deviceId] || 0;
      const lastVec = lastVectorPerDevice[deviceId] || new Array(VECTOR_PROCESS_COUNT).fill(0);
      const lamportIsHigher = (receivedLamportTS > lastLamport);
      const vecIsConsistent = vectorIsConsistent(receivedVectorClock, lastVec);

      if (lamportIsHigher && vecIsConsistent) {
        console.log(`[WARN] Timestamp fuera de rango (|${deltaMs}ms|) pero aceptado por coherencia lógica (Lamport/Vector). Forzando HoraLocal.`);
        // Force timestamp to local time for storage
        data._stored_timestamp_forced = new Date(localTime).toISOString();
        // Accept but update logical clocks
        lastLamportPerDevice[deviceId] = Math.max(lastLamportPerDevice[deviceId] || 0, receivedLamportTS);
        lastVectorPerDevice[deviceId] = receivedVectorClock.slice();
        // Continue to write to DB but with forced timestamp
      } else {
        // Reject and log exactly the string the chaos script looks for
        console.warn('Rejected future packet: timestamp out of acceptable range (>2s).', { deviceId, timestamp: data.timestamp });
        return;
      }
    } else {
      // Normal acceptance: update last known logical clocks
      lastLamportPerDevice[deviceId] = Math.max(lastLamportPerDevice[deviceId] || 0, receivedLamportTS);
      lastVectorPerDevice[deviceId] = receivedVectorClock.slice();
    }

    // Prepare Influx point (use forced timestamp if present)
    const storeTs = data._stored_timestamp_forced ? new Date(data._stored_timestamp_forced) : new Date(data.timestamp);

    const point = new Point('sensor_data')
      .tag('device_id', deviceId)
      .floatField('temperature', parseFloat(data.temperatura))
      .floatField('humidity', parseFloat(data.humedad))
      .intField('lamport_ts_sensor', receivedLamportTS)
      .tag('lamport_ts_persistence', lamportClock.toString())
      .tag('vector_clock_sensor', JSON.stringify(receivedVectorClock))
      .tag('vector_clock_persistence', JSON.stringify(vectorClock))
      .timestamp(storeTs);

    console.log(`[DB] Preparando punto para InfluxDB (device=${deviceId}, ts=${storeTs.toISOString()})`);
    writeApi.writePoint(point);
    writeApi.flush().then(() => {
      console.log('[DB] Punto escrito exitosamente en InfluxDB.');
    }).catch(error => {
      console.error('[ERROR] Error al escribir en InfluxDB:', error);
    });

  } catch (error) {
    console.error('[ERROR] Error al procesar mensaje MQTT o escribir en DB:', error);
  }
});

// Cleanup
process.on('SIGINT', async () => {
  console.log('\n[INFO] Cerrando conexiones...');
  mqttClient.end();
  try {
    await writeApi.close();
    console.log('[INFO] Conexión InfluxDB cerrada.');
  } catch (e) {
    console.error('[ERROR] Error cerrando InfluxDB:', e);
  }
  process.exit(0);
});
