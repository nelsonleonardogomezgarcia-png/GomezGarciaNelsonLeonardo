// /publisher/publisher.js

const mqtt = require('mqtt');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// --- Configuración Básica ---
const CLOCK_DRIFT_RATE = parseFloat(process.env.CLOCK_DRIFT_RATE || '0');
const DEVICE_ID = process.env.DEVICE_ID || 'sensor-default';
const PROCESS_ID = parseInt(process.env.PROCESS_ID || '0');

// --- ELECCIÓN Y LEASES ---
const MY_PRIORITY = parseInt(process.env.PROCESS_PRIORITY || '0');
const ELECTION_PARTICIPANTS = (process.env.ELECTION_PARTICIPANTS || '').split(',').filter(Boolean); // sensor-1:10,...
const LEASE_TOPIC = 'utp/sistemas_distribuidos/grupo1/election/lease';
const LEASE_RENEW_INTERVAL_MS = 2000; // publicar lease cada 2s
const LEASE_DURATION_MS = 5000;       // lease dura 5s
const LEADER_TIMEOUT = LEASE_DURATION_MS; // si no vemos renewal -> start election
const VOTE_REQUEST_TOPIC = 'utp/sistemas_distribuidos/grupo1/election/vote_request';
const VOTE_ACK_TOPIC = 'utp/sistemas_distribuidos/grupo1/election/vote_ack';
const ELECTION_MSG_TOPIC = 'utp/sistemas_distribuidos/grupo1/election/messages';
const ELECTION_COORDINATOR_TOPIC = 'utp/sistemas_distribuidos/grupo1/election/coordinator';

let isCoordinator = false;
let electionInProgress = false;
let lastLeaseTimestamp = 0;
let leaseRenewTimer = null;
let voteCount = 0;
let awaitingVotesFrom = new Set();
let voteTimeoutHandle = null;

// --- Mutex state (coordinator) ---
let coord_isLockAvailable = true;
let coord_lockHolder = null;
let coord_waitingQueue = [];

// WAL path (ensure docker-compose mounts /data to a volume)
const WAL_PATH = process.env.WAL_PATH || '/data/wal.log';

// --- Sincronización Reloj (Cristian, Lamport, Vector) ---
let lastRealTime = Date.now();
let lastSimulatedTime = Date.now();
let clockOffset = 0;
let lamportClock = 0;
const VECTOR_PROCESS_COUNT = 5;
let vectorClock = new Array(VECTOR_PROCESS_COUNT).fill(0);

// --- MQTT ---
const statusTopic = config.topics.status(DEVICE_ID);
const brokerUrl = `mqtt://${config.broker.address}:${config.broker.port}`;
const client = mqtt.connect(brokerUrl, {
  clientId: `pub_${DEVICE_ID}_${Math.random().toString(16).slice(2, 5)}`,
  will: { topic: statusTopic, payload: JSON.stringify({ deviceId: DEVICE_ID, status: 'offline' }), qos: 1, retain: true }
});

// --- HELPERS: WAL ---
function walAppend(op) {
  try {
    const dir = path.dirname(WAL_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(WAL_PATH, JSON.stringify(op) + '\n');
    console.log(`[WAL] Appended op: ${JSON.stringify(op)}`);
  } catch (e) {
    console.error('[WAL] Error appending to wal:', e);
  }
}

function walRecover() {
  try {
    if (!fs.existsSync(WAL_PATH)) return [];
    const lines = fs.readFileSync(WAL_PATH, 'utf8').trim().split('\n').filter(Boolean);
    const ops = lines.map(l => JSON.parse(l));
    const queue = ops.filter(o => o.op === 'enqueue').map(o => o.deviceId);
    console.log(`[RECOVERY] Restored queue: [${queue.join(', ')}]`);
    return queue;
  } catch (e) {
    console.error('[RECOVERY] Error reading WAL:', e);
    return [];
  }
}

// ============================================================================
//                            LÓGICA MQTT Y CICLO DE VIDA
// ============================================================================
client.on('connect', () => {
  console.log(`[INFO] ${DEVICE_ID} (Prio: ${MY_PRIORITY}) conectado.`);

  // Suscripciones
  client.subscribe(config.topics.time_response(DEVICE_ID));
  client.subscribe(config.topics.mutex_grant(DEVICE_ID));
  client.subscribe(ELECTION_MSG_TOPIC);
  client.subscribe(ELECTION_COORDINATOR_TOPIC);
  client.subscribe(VOTE_REQUEST_TOPIC);
  client.subscribe(VOTE_ACK_TOPIC);
  client.subscribe(LEASE_TOPIC);

  // Ciclos
  setInterval(publishTelemetry, 5000);
  setInterval(syncClock, 30000);
  setTimeout(() => { setInterval(requestCalibration, 20000 + (Math.random()*5000)); }, 5000);
  setInterval(checkLeaderStatus, 1000);
  setInterval(sendHeartbeatSimple, 2000);

  client.publish(statusTopic, JSON.stringify({ deviceId: DEVICE_ID, status: 'online' }), { retain: true });
});

// ============================================================================
// CRISTIAN MEJORADO: Solicitar hora y calcular RTT. Si RTT>500ms -> descartar.
// El servidor de tiempo debe reenviar t1 tal como se lo enviamos.
client.on('message', (topic, message) => {
  try {
    const payload = JSON.parse(message.toString());

    // Time response
    if (topic === config.topics.time_response(DEVICE_ID)) {
      const t1 = payload.t1 || 0;
      const serverTime = payload.serverTime || Date.now();
      const rtt = Date.now() - t1;
      console.log(`[TIME] Received time response. RTT=${rtt}ms`);
      if (rtt > 500) {
        console.warn(`[TIME] RTT ${rtt}ms > 500ms => sincronización descartada.`);
        return;
      }
      const correctedTime = serverTime + (rtt / 2);
      clockOffset = correctedTime - getSimulatedTime().getTime();
      console.log(`[TIME] Clock offset ajustado a ${clockOffset}ms`);
      return;
    }

    // Election messages
    if (topic === ELECTION_MSG_TOPIC) {
      handleElectionMessages(payload);
      return;
    }

    // Vote request (otro candidato pide voto)
    if (topic === VOTE_REQUEST_TOPIC) {
      // Si el requester tiene mayor prioridad que yo, le doy ACK (voto)
      if (payload && payload.priority && payload.requesterId) {
        if (payload.priority > MY_PRIORITY) {
          client.publish(VOTE_ACK_TOPIC, JSON.stringify({ to: payload.requesterId, from: DEVICE_ID, priority: MY_PRIORITY }));
          console.log(`[VOTE] Voté por ${payload.requesterId} (prio ${payload.priority})`);
        } else {
          // no votamos por uno de menor prioridad
          console.log(`[VOTE] Ignoro petición de voto de ${payload.requesterId} (prio ${payload.priority} <= ${MY_PRIORITY})`);
        }
      }
      return;
    }

    // Vote ack (recibo votos)
    if (topic === VOTE_ACK_TOPIC) {
      if (payload && payload.to === DEVICE_ID) {
        voteCount++;
        console.log(`[VOTE] Recibido ACK de ${payload.from}. Total votos=${voteCount}`);
        // Si alcanzamos quórum
        const required = Math.floor((ELECTION_PARTICIPANTS.length || 5) / 2) + 1;
        if (voteCount >= required && electionInProgress) {
          console.log(`[VOTE] Won election with ${voteCount} votes`);
          clearTimeout(voteTimeoutHandle);
          declareVictory();
        }
      }
      return;
    }

    // Lease topic: actualización del líder
    if (topic === LEASE_TOPIC) {
      if (payload && payload.leaderId && payload.priority !== undefined && payload.expiry) {
        lastLeaseTimestamp = Date.now();
        // Si lease indica otro líder con mayor prioridad, paso a follower
        if (payload.leaderId !== DEVICE_ID) {
          if (payload.priority > MY_PRIORITY) {
            if (isCoordinator) {
              console.log('Lease indicates higher priority leader, stepping down.');
              stepDownFromLeader('Lease indicated superior leader');
            } else {
              isCoordinator = false;
            }
          }
        }
      }
      return;
    }

    // Mutex grant
    if (topic === config.topics.mutex_grant(DEVICE_ID) && payload && payload.status === 'granted') {
      console.log(`[MUTEX-CLIENT] Permiso recibido.`);
      enterCriticalSection();
      return;
    }

  } catch (e) {
    console.error('[ERROR] Procesando mensaje MQTT:', e);
  }
});

// ============================================================================
// ELECTION / LEASE LOGIC
// ============================================================================

function startElection() {
  if (electionInProgress) return;
  electionInProgress = true;
  voteCount = 0;
  awaitingVotesFrom = new Set();

  console.log(`[ELECTION] Iniciando elección. Pidiendo votos...`);

  // 1) Publicar petición de voto (cada nodo decide si votar)
  client.publish(VOTE_REQUEST_TOPIC, JSON.stringify({ requesterId: DEVICE_ID, priority: MY_PRIORITY }));

  // 2) Esperar ACKs
  const required = Math.floor((ELECTION_PARTICIPANTS.length || 5) / 2) + 1;
  voteTimeoutHandle = setTimeout(() => {
    if (voteCount >= required) {
      console.log(`[ELECTION] Got quorum (${voteCount}).`);
      declareVictory();
    } else {
      console.log(`[ELECTION] No se obtuvo quórum (${voteCount}). Quedo en CANDIDATE.`);
      electionInProgress = false;
      // No otorgamos recursos mientras no seamos líder
    }
  }, 3000); // tiempo de espera por votos (3s)
}

function declareVictory() {
  // Publish coordinator announcement (retained)
  client.publish(ELECTION_COORDINATOR_TOPIC, JSON.stringify({ type: 'VICTORY', coordinatorId: DEVICE_ID, priority: MY_PRIORITY }), { retain: true });
  becomeCoordinator();
}

function becomeCoordinator() {
  if (isCoordinator) return;
  isCoordinator = true;
  electionInProgress = false;
  console.log(`[ROLE] *** ASCENDIDO A COORDINADOR DE BLOQUEO ***`);

  // Recover WAL before serving
  const recoveredQueue = walRecover();
  if (recoveredQueue && recoveredQueue.length > 0) {
    coord_waitingQueue = recoveredQueue;
    console.log(`[RECOVERY] Restored queue: [${coord_waitingQueue.join(', ')}]`);
  } else {
    coord_waitingQueue = [];
  }
  coord_isLockAvailable = true;
  coord_lockHolder = null;

  client.subscribe(config.topics.mutex_request, { qos: 1 });
  client.subscribe(config.topics.mutex_release, { qos: 1 });

  // Start renewing lease
  publishLease(); // immediate
  if (leaseRenewTimer) clearInterval(leaseRenewTimer);
  leaseRenewTimer = setInterval(publishLease, LEASE_RENEW_INTERVAL_MS);
}

function stepDownFromLeader(reason) {
  if (!isCoordinator) return;
  console.log(`Lease expired. Stepping down. Reason: ${reason}`);
  isCoordinator = false;
  if (leaseRenewTimer) {
    clearInterval(leaseRenewTimer);
    leaseRenewTimer = null;
  }
  // Unsubscribe mutex topics
  client.unsubscribe(config.topics.mutex_request);
  client.unsubscribe(config.topics.mutex_release);
}

function publishLease() {
  const payload = { leaderId: DEVICE_ID, priority: MY_PRIORITY, expiry: Date.now() + LEASE_DURATION_MS };
  client.publish(LEASE_TOPIC, JSON.stringify(payload), { retain: true });
  lastLeaseTimestamp = Date.now();
  //console.log(`[LEASE] Published lease (expiry in ${LEASE_DURATION_MS}ms).`);
}

// Monitor lease: if no renewal in LEADER_TIMEOUT, start election
function checkLeaderStatus() {
  if (isCoordinator) return;
  if (Date.now() - lastLeaseTimestamp > LEADER_TIMEOUT) {
    console.warn(`[ELECTION] No se detectó renovación de lease > ${LEADER_TIMEOUT}ms. Iniciando elección.`);
    startElection();
  }
}

// Handle incoming ELECTION generic messages (keep simple for compatibility)
function handleElectionMessages(payload) {
  if (!payload || !payload.type) return;
  if (payload.type === 'ELECTION') {
    if (payload.fromPriority < MY_PRIORITY) {
      // respond ALIVE
      client.publish(ELECTION_MSG_TOPIC, JSON.stringify({ type: 'ALIVE', toPriority: payload.fromPriority, fromPriority: MY_PRIORITY }));
      startElection();
    }
  }
}

// ============================================================================
// MUTEX COORDINATOR LOGIC (cuando isCoordinator === true)
// ============================================================================

function handleCoordRequest(requesterId) {
  console.log(`[COORD] Procesando solicitud de: ${requesterId}`);
  if (coord_isLockAvailable) {
    grantCoordLock(requesterId);
  } else {
    if (!coord_waitingQueue.includes(requesterId) && coord_lockHolder !== requesterId) {
      coord_waitingQueue.push(requesterId);
      // WAL: loguear enqueue
      walAppend({ op: 'enqueue', deviceId: requesterId, ts: Date.now() });
    }
  }
  publishCoordStatus();
}

function handleCoordRelease(requesterId) {
  if (coord_lockHolder === requesterId) {
    console.log(`[COORD] Liberado por: ${requesterId}`);
    coord_lockHolder = null;
    coord_isLockAvailable = true;
    if (coord_waitingQueue.length > 0) {
      grantCoordLock(coord_waitingQueue.shift());
    }
  }
  publishCoordStatus();
}

function grantCoordLock(requesterId) {
  coord_isLockAvailable = false;
  coord_lockHolder = requesterId;
  client.publish(config.topics.mutex_grant(requesterId), JSON.stringify({ status: 'granted' }), { qos: 1 });
}

function publishCoordStatus() {
  client.publish(config.topics.mutex_status, JSON.stringify({
    isAvailable: coord_isLockAvailable,
    holder: coord_lockHolder,
    queue: coord_waitingQueue
  }), { retain: true });
}

// ============================================================================
// MUTEX CLIENT
// ============================================================================

function requestCalibration() {
  if (!isCoordinator) {
    console.log(`[MUTEX-CLIENT] Solicitando...`);
    client.publish(config.topics.mutex_request, JSON.stringify({ deviceId: DEVICE_ID }), { qos: 1 });
  }
}

function enterCriticalSection() {
  setTimeout(() => {
    console.log(`[MUTEX-CLIENT] Fin calibración.`);
    releaseLock();
  }, 5000);
}

function releaseLock() {
  client.publish(config.topics.mutex_release, JSON.stringify({ deviceId: DEVICE_ID }), { qos: 1 });
}

// ============================================================================
// UTIL / TELEMETRÍA / CRON
// ============================================================================

function getSimulatedTime() {
  const now = Date.now();
  const realElapsed = now - lastRealTime;
  const simulatedElapsed = realElapsed + (realElapsed * CLOCK_DRIFT_RATE / 1000);
  lastSimulatedTime = lastSimulatedTime + simulatedElapsed;
  lastRealTime = now;
  return new Date(Math.floor(lastSimulatedTime));
}

function syncClock() {
  const payload = JSON.stringify({ deviceId: DEVICE_ID, t1: Date.now() });
  client.publish(config.topics.time_request, payload, { qos: 0 });
}

function sendHeartbeatSimple() {
  // publish a small PING on election messages so that old bully logic still sees activity
  client.publish(ELECTION_MSG_TOPIC, JSON.stringify({ type: 'HEARTBEAT', fromPriority: MY_PRIORITY }));
}

function publishTelemetry() {
  lamportClock++;
  vectorClock[PROCESS_ID]++;

  const correctedTime = new Date(getSimulatedTime().getTime() + clockOffset);

  const telemetryData = {
    deviceId: DEVICE_ID,
    temperatura: parseFloat((Math.random() * 30).toFixed(2)),
    humedad: parseFloat((Math.random() * 100).toFixed(2)),
    timestamp: correctedTime.toISOString(),
    timestamp_simulado: getSimulatedTime().toISOString(),
    clock_offset: clockOffset.toFixed(0),
    lamport_ts: lamportClock,
    vector_clock: [...vectorClock],
    sensor_state: isCoordinator ? 'COORDINATOR' : 'CLIENT'
  };
  client.publish(config.topics.telemetry(DEVICE_ID), JSON.stringify(telemetryData));
}
